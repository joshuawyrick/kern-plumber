import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://kernplumbingpros.com',
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  compressHTML: true,
  vite: { build: { cssMinify: true } }
});
