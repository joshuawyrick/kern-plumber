# Kern Plumbing Pros

Production-ready, fully static Astro website generated from the supplied build specification and English/Spanish content packs.

## Local development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run audit
```

The deploy output is generated in `dist/`. Netlify is configured by `netlify.toml` to run `npm run build` and publish `dist`.

## Before launch

1. Replace the placeholder phone number if required in `src/lib/site.ts`.
2. Replace `G-XXXXXXXXXX` with the real GA4 measurement ID in `src/lib/site.ts`.
3. Replace the CallRail placeholder comment in `src/layouts/BaseLayout.astro` with the real DNI snippet.
4. Confirm `FORM_ENDPOINT` in `src/lib/site.ts` and activate the FormSubmit recipient email.
5. Replace placeholder imagery and review slots only with real business assets and real reviews.
6. Add final approved content for the routes listed as missing pack blocks in `AUDIT-REPORT.md`.

## Deployment

Upload the repository to Netlify or connect it to Git. No server runtime is required; every page is prerendered as static HTML.
