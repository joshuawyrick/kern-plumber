# UNIVERSAL HIGH-END WEBSITE AESTHETIC DIRECTION

Design the website as an ultra-premium, light-theme digital experience with the polish, precision, and visual confidence of a nationally recognized professional brand.

The finished website must feel custom-designed by a senior brand designer, art director, UI designer, and conversion-focused product design team. It must not resemble a prebuilt template, generic page-builder theme, inexpensive local-business website, or AI-generated first draft.

The design should communicate:

* Professionalism
* Trust
* Competence
* Reliability
* Organization
* Responsiveness
* Stability
* Quality
* Attention to detail
* Established business credibility

The visual experience should feel sophisticated, modern, calm, clear, and highly intentional. It should look expensive without appearing luxurious, flashy, trendy, theatrical, or overly decorative.

Do not use a dark theme.

## Overall Visual Character

Create a refined visual blend of:

* Premium corporate branding
* Modern enterprise software
* High-end editorial web design
* Professional service branding
* Contemporary architecture
* Clean operational interfaces
* Sophisticated digital product design

The website should feel established and professionally managed.

It should give visitors the impression that the business is organized, dependable, experienced, and capable of handling important customer needs.

The design must feel human and approachable while still maintaining the polish of a large professional organization.

Avoid any appearance that feels:

* Cheap
* Amateur
* Aggressive
* Overly promotional
* Cluttered
* Gimmicky
* Trend-dependent
* Cartoonish
* Cold and sterile
* Visually chaotic
* Like a generic landing-page template
* Like an unedited AI-generated design

## Light-Theme Color Direction

Use a sophisticated light color system built around warm whites, soft neutrals, muted grays, deep graphite, and one restrained brand accent.

The majority of the website should remain bright, open, and visually calm.

Recommended foundation:

* Main background: warm white rather than stark white
* Primary surfaces: clean white
* Secondary surfaces: pale neutral gray
* Alternate surfaces: very light cool gray or subtle warm stone
* Primary text: deep graphite, charcoal, or dark navy
* Secondary text: muted slate gray
* Tertiary text: soft medium gray
* Borders: pale cool gray
* Strong dividers: slightly darker neutral gray

Use one primary brand color that feels trustworthy, mature, and professional.

Suitable visual directions include:

* Deep blue
* Muted navy
* Refined teal
* Deep green
* Sophisticated burgundy
* Controlled warm copper
* Muted amber
* Another restrained professional color appropriate to the supplied brand

Use the accent color selectively.

It should appear in:

* Primary buttons
* Active navigation states
* Important links
* Small icon details
* Focus states
* Compact labels
* Selected interface highlights
* Subtle decorative lines

The accent color should never overwhelm the layout.

Do not use several competing accent colors.

Avoid:

* Large black backgrounds
* Large dark navy sections
* Neon colors
* Harsh primary colors
* Oversaturated gradients
* Metallic effects
* Chrome effects
* Rainbow color systems
* Excessive use of red
* Bright color behind large amounts of text
* Multiple button colors competing for attention

## Background Treatment

Keep most of the site bright and spacious.

Create visual rhythm through subtle changes between:

* Warm white
* Pure white
* Pale gray
* Soft cool-neutral surfaces
* Very subtle tinted backgrounds

Section transitions should feel elegant and almost architectural.

Do not create harsh horizontal stripes where every section uses a dramatically different background.

Introduce depth through:

* Thin borders
* Layered white surfaces
* Delicate tonal shifts
* Subtle overlaps
* Faint shadows
* Controlled background patterns
* Soft geometric forms
* Minimal line work

Optional decorative background elements may include:

* Faint grid lines
* Soft abstract curves
* Minimal architectural line patterns
* Subtle oversized typography
* Fine directional lines
* Low-opacity geometric forms
* Light editorial framing devices

These elements should remain barely visible.

They must support the composition without becoming noticeable decoration.

Avoid:

* Grunge textures
* Distressed surfaces
* Heavy patterns
* Repeating icons
* Loud abstract blobs
* Bright gradient mesh backgrounds
* Particle effects
* Fake three-dimensional environments
* Decorative visual noise

## Typography

Typography should be one of the strongest visual features of the design.

Use a premium contemporary sans-serif typeface with excellent readability.

Suitable directions include:

* Manrope
* Geist
* Inter
* Plus Jakarta Sans
* Söhne-style typography
* Graphik-style typography
* Helvetica Now-style typography
* Neue Montreal-style typography
* Another refined modern sans-serif with a broad weight range

Use one primary type family whenever possible.

A second typeface may be introduced only when it meaningfully improves the visual identity.

Headlines should feel:

* Confident
* Clean
* Compact
* Editorial
* Modern
* Highly legible
* Carefully composed

Use slightly tight letter spacing for large headings.

Control line breaks intentionally so headlines do not appear accidental or awkward.

Large headings should generally occupy two or three well-balanced lines rather than stretching across the entire screen.

Body text should feel calm and effortless to read.

Use:

* Comfortable line height
* Moderate line length
* Clear paragraph spacing
* Strong contrast
* Consistent text widths
* Deliberate hierarchy

Small labels may use:

* Slightly increased letter spacing
* Medium font weight
* Uppercase or restrained small-cap styling
* Compact visual treatment

Do not overuse uppercase text.

Avoid:

* Decorative fonts
* Script fonts
* Novelty fonts
* Extremely condensed fonts
* Overly geometric futuristic fonts
* Excessive italics
* Thin low-contrast type
* Giant text used only for visual impact
* Tiny body text
* Excessive bolding
* Long centered paragraphs

Most body content should be left aligned.

Centered text should be reserved for short, intentionally composed sections.

## Layout and Composition

Use a disciplined grid system with precise alignment and generous whitespace.

The desktop design should feel wide, balanced, and editorial.

Use a consistent maximum content width and carefully controlled horizontal padding.

The composition should rely on:

* Strong alignment
* Deliberate proportions
* Clear visual hierarchy
* Generous breathing room
* Carefully limited text widths
* Balanced use of imagery
* Consistent vertical rhythm
* Thoughtful asymmetry
* Refined surface layering

Avoid placing every element inside a card.

The design should use a combination of:

* Open layouts
* Editorial columns
* Image-and-text compositions
* Thin dividers
* Framed content areas
* Selectively elevated panels
* Offset sections
* Large visual moments
* Compact supporting elements

Use cards only when grouping information genuinely improves comprehension.

The site should feel designed as a complete visual composition rather than assembled from a library of interchangeable blocks.

Preferred desktop compositions include:

* 60/40 splits
* 55/45 splits
* Offset columns
* Large visual areas paired with narrower text columns
* One dominant element supported by smaller secondary elements
* Asymmetrical layouts balanced through spacing
* Layered panels that subtly overlap nearby surfaces

Maintain clear structure even when using asymmetry.

Nothing should feel random.

## Whitespace

Use generous whitespace as a primary design tool.

Whitespace should communicate quality, confidence, and organization.

Provide ample space:

* Around headings
* Between major sections
* Between text and imagery
* Inside important panels
* Around calls to action
* Between interface controls
* Above and below dividers

Do not fill every available area.

Avoid excessive density.

At the same time, do not create large empty sections that make the page feel unfinished.

Whitespace should always support hierarchy and pacing.

## Shape Language

Use a precise, refined shape system.

Corners should be softly rounded but not exaggerated.

Recommended character:

* Buttons: modest radius
* Inputs: modest radius
* Small panels: medium radius
* Large image frames: slightly larger radius
* Large content surfaces: controlled, consistent radius

Avoid making every component pill-shaped.

Reserve fully rounded shapes for:

* Small labels
* Status indicators
* Compact tags
* Tiny interface controls
* Avatars
* Minimal decorative markers

The overall shape language should feel professional, structured, and mature rather than playful or overly soft.

## Borders

Use thin, low-contrast borders to define surfaces.

Borders should appear precise and subtle.

Use them for:

* Cards
* Input fields
* Navigation separation
* Content panels
* Image frames
* Accordions
* Table-like structures
* Small informational groups

Borders should generally be one pixel and use a pale neutral tone.

Use stronger borders only when creating intentional emphasis.

Avoid:

* Thick outlines
* Dark card borders
* Double borders
* Decorative borders
* Bright accent borders around every component
* Heavy boxed-in layouts

## Shadows

Use shadows sparingly.

Most surfaces should rely on spacing, background contrast, and borders rather than elevation.

When shadows are used, they should be:

* Broad
* Soft
* Low opacity
* Neutral in tone
* Barely noticeable
* Consistent throughout the site

Stronger elevation may be used selectively for:

* A floating panel
* A dropdown
* A sticky interface element
* A modal
* A prominent overlapping surface

Avoid:

* Hard drop shadows
* Large dark shadows
* Glowing effects
* Multiple stacked shadows
* Colored shadows
* Shadows around every card
* Shadows that make components appear to float excessively

## Header Aesthetic

The header should feel like a premium enterprise navigation system.

Use a bright white or warm-white background with a very subtle lower border.

The logo should have generous space around it.

Navigation items should feel quiet, precise, and evenly spaced.

The header should communicate:

* Stability
* Clarity
* Professionalism
* Order
* Confidence

Do not overcrowd the header.

Use one visually dominant action at most.

Secondary actions should be quieter.

The sticky header state should remain compact and refined.

A subtle change in shadow, border, or background opacity may occur when the page scrolls.

Avoid:

* Oversized headers
* Heavy dark navigation bars
* Multiple brightly colored buttons
* Large promotional banners
* Excessive icons
* Giant contact details
* Flashing notices
* Thick shadows
* Overly animated navigation
* Crowded dropdowns

## Hero Aesthetic

The hero should establish immediate visual authority.

Use a sophisticated composition with strong typography, generous whitespace, and a carefully selected visual focal point.

Preferred structure:

* Bright neutral background
* Large left-aligned headline
* Concise supporting text
* One prominent primary action
* One restrained secondary action
* Small supporting labels or trust indicators
* A large, carefully cropped visual area
* Optional overlapping detail panel

The hero should feel substantial without filling the entire viewport unnecessarily.

Avoid a generic centered headline floating over a full-width stock photograph.

Preferred visual arrangements include:

* Split-screen composition
* Offset visual panel
* Large image beside text
* Image framed within a refined surface
* Editorial collage using no more than two or three coordinated visual elements
* One dominant image with a small overlapping information panel

The hero imagery should feel authentic, polished, and naturally integrated.

Do not apply a heavy dark overlay.

Keep photography bright and clear.

Avoid:

* Full-screen background videos
* Generic handshake photography
* Obvious stock-photo poses
* Overly staged smiling subjects
* Dramatic cinematic effects
* Excessive image filters
* Heavy HDR processing
* Bright colored overlays
* Large floating decorative shapes
* Several competing hero messages
* Giant typography with no supporting structure

## Photography Direction

Use a consistent and intentional photographic style throughout the site.

Photography should feel:

* Authentic
* Editorial
* Contemporary
* Professional
* Naturally lit
* Clean
* Credible
* Carefully composed

Preferred photographic qualities:

* Neutral or slightly warm color grading
* Crisp detail
* Natural daylight
* Strong composition
* Controlled depth
* Real environments
* Genuine human interaction
* Thoughtful negative space
* Clean visual backgrounds
* Consistent lighting style

People should appear naturally engaged rather than posing directly for the camera.

Use a mixture of:

* Wide environmental images
* Medium contextual images
* Selective close-up detail images
* Human interaction
* Tools, materials, environments, or objects relevant to the provided business context

Do not introduce imagery that assumes a specific industry unless that industry has been supplied elsewhere in the project requirements.

All visuals must be selected based on the actual business information provided to the agent.

Avoid:

* Unrelated imagery
* Generic office teams
* Artificially perfect models
* Exaggerated expressions
* Inconsistent color grading
* Low-resolution images
* Visually busy backgrounds
* Unsafe or implausible scenes
* Images containing incorrect text
* Distorted AI-generated hands, objects, tools, or environments

A smaller number of visually consistent, high-quality images is better than a large number of unrelated images.

## Image Cropping

Crop images with intention.

Use:

* Strong focal points
* Clear subject placement
* Generous negative space
* Balanced horizon lines
* Visual breathing room
* Consistent aspect ratios
* Editorial framing

Avoid random crops that cut off important details.

Do not place faces, hands, objects, or key visual information beneath text or interface controls.

Use image radiuses consistently.

Large feature images may use a slightly larger radius than smaller supporting images.

## Iconography

Use refined line icons with a custom-designed appearance.

Icons should have:

* Consistent stroke width
* Simple geometry
* Rounded line endings
* Minimal internal detail
* Clear visual meaning
* Professional proportions

Use icons sparingly.

They should support comprehension rather than decorate every element.

Preferred icon colors:

* Dark graphite
* Muted slate
* Primary brand color
* Small accent details where appropriate

Avoid:

* Clip art
* Cartoon icons
* Emoji
* Multicolored icon sets
* Detailed illustrations used as icons
* Shiny three-dimensional icons
* Thick inconsistent strokes
* Oversized icons inside large circles
* Icons displayed beside every line of text

## Card Design

Cards should feel refined and intentional.

Use cards only when content belongs together as a distinct group.

A premium card may use:

* White background
* Thin border
* Generous internal spacing
* Clear title hierarchy
* Minimal supporting icon
* Restrained metadata
* Subtle hover response
* Little or no shadow

Vary card scale when appropriate.

One item may be visually dominant while supporting items are more compact.

Avoid a layout where every section becomes a grid of identical rounded rectangles.

Do not use:

* Oversized icons
* Brightly colored card backgrounds everywhere
* Heavy shadows
* Thick borders
* Excessive rounded corners
* Large decorative gradients
* Unnecessary hover animation
* Too much text inside a card

## Buttons

Buttons should feel solid, precise, and premium.

Primary buttons should use:

* The main brand color
* High-contrast text
* Moderate corner radius
* Comfortable horizontal padding
* Clear typography
* Minimal or no shadow
* A subtle hover state
* A restrained icon only when useful

Secondary buttons should use:

* White or transparent background
* Thin neutral or brand-colored border
* Dark text
* Subtle hover fill
* The same dimensions and typography discipline as primary buttons

Buttons should not feel inflated or overly soft.

Avoid:

* Large pill buttons
* Gradient fills
* Glowing buttons
* Pulsing animation
* Excessive icons
* Several competing button colors
* Oversized buttons with very little text
* All-uppercase labels
* Dramatic hover movement
* Thick shadows

Button hierarchy must remain immediately understandable.

## Links

Text links should feel intentional and visible.

Use:

* Clear contrast
* Subtle underline treatment
* Small directional icon where useful
* Refined hover transition
* Strong keyboard focus state

Avoid generic blue browser-style links unless that appearance is part of the brand system.

Do not animate underlines excessively.

## Form Aesthetic

Forms should resemble premium enterprise software.

Use:

* Clean white inputs
* Thin neutral borders
* Labels positioned above fields
* Generous vertical spacing
* Consistent control heights
* Strong alignment
* Clear focus states
* Calm instructional text
* Refined validation states
* Subtle grouping of related fields

Large forms may sit inside a softly elevated white surface on a pale neutral background.

Inputs should feel substantial but not oversized.

Use accent color for focus states rather than heavy shadows.

Avoid:

* Placeholder-only labels
* Thick borders
* Dark form backgrounds
* Floating-label gimmicks
* Excessive icons inside inputs
* Large colored field backgrounds
* Heavy shadows
* Bright red validation everywhere
* Crowded multi-column forms
* Decorative illustrations beside every form

Success, warning, and error states should feel polished and consistent with the design system.

## Navigation Menus

Dropdown menus should feel structured and spacious.

Use:

* Clean white surfaces
* Thin borders
* Soft shadow
* Clear grouping
* Calm typography
* Restrained icons
* Generous clickable areas
* Deliberate spacing

Avoid huge dropdowns unless the content genuinely requires one.

Do not use promotional imagery inside navigation unless it is visually subtle and clearly useful.

Mobile navigation should feel like a designed interface, not a raw list of links.

## Section Transitions

Sections should flow naturally.

Use transitions created through:

* Spacing
* Background tone
* Thin rules
* Image placement
* Typography
* Subtle overlaps
* Controlled surface changes

Avoid inserting large decorative separators between every section.

Do not use repeated waves, diagonal cuts, or oversized curves.

The page should feel cohesive from top to bottom.

## Information Hierarchy

Each section should have one clear visual priority.

Use a consistent hierarchy:

* Small context label
* Strong section headline
* Short supporting text
* Main visual or information group
* Secondary supporting details
* Restrained action

Do not allow several elements within the same section to compete for attention.

Keep supporting content visually quieter than the main message.

Use color, scale, spacing, and weight with discipline.

## Trust Elements

Trust-related design should feel understated and credible.

Use:

* Clean typography
* Restrained symbols
* Monochrome marks
* Neutral surfaces
* Thin dividers
* Compact metadata
* Small supporting labels
* Authentic imagery
* Consistent alignment

Avoid:

* Giant stars
* Oversized badges
* Cartoon shields
* Bright seals
* Busy logo walls
* Large quotation marks
* Decorative testimonial bubbles
* Excessive numerical claims displayed as visual spectacle

Partner, certification, or association marks should preferably appear in grayscale or muted monochrome unless their official brand guidelines prohibit alteration.

## Testimonial Aesthetic

Testimonials should feel editorial and believable.

Use:

* Restrained quotation styling
* Comfortable text width
* Small customer attribution
* Clear hierarchy
* Minimal star treatment
* Neutral surface
* Thin separators
* Optional authentic portrait or logo when supplied

Avoid:

* Giant quote icons
* Cartoon speech bubbles
* Bright card backgrounds
* Busy carousels
* Overly large star ratings
* Long testimonial walls
* Artificially polished marketing language

## Data and Statistics

When verified data is provided, present it with restraint.

Use:

* Large but controlled numerals
* Small descriptive labels
* Thin dividers
* Clear alignment
* Muted supporting text
* Minimal graphical treatment

Do not use animated counters unless motion has a clear purpose.

Avoid oversized statistics that dominate the page without context.

Do not invent live dashboards or operational data.

## Illustrations and Graphics

Use illustrations only when they improve clarity or brand distinction.

Preferred illustration style:

* Minimal
* Geometric
* Flat or lightly dimensional
* Limited color palette
* Clean line work
* Consistent with the primary brand
* Sophisticated rather than playful

Avoid:

* Cartoon characters
* Mascot illustrations
* Generic vector people
* Bright abstract scenes
* Overly detailed diagrams
* Isometric office illustrations
* Stock illustration packs
* Several unrelated illustration styles

## Tables and Structured Information

Structured information should feel clean and easy to scan.

Use:

* Light borders
* Soft row separation
* Strong column alignment
* Calm text hierarchy
* Subtle header backgrounds
* Generous cell padding
* Minimal accent color

Avoid:

* Dense spreadsheet styling
* Heavy grid lines
* Dark table headers
* Excessive alternating colors
* Tiny text
* Too many columns on small screens

## Footer Aesthetic

The footer should feel organized, spacious, and intentionally designed.

Prefer:

* Pale gray
* Soft stone
* Light blue-gray
* Warm neutral
* A restrained medium-dark brand surface only when appropriate

The footer should not automatically become a giant black section.

Use:

* Clear column structure
* Generous spacing
* Small uppercase or medium-weight labels
* Calm link styling
* Thin dividers
* A clear visual relationship to the rest of the site

Avoid:

* Crowded sitemap layouts
* Dozens of small links
* Giant promotional sections
* Heavy gradients
* Decorative background imagery
* Bright social-media icon colors
* Excessive legal text dominating the composition

## Motion and Interaction

Motion should be subtle enough that users notice responsiveness rather than animation.

Use:

* Gentle opacity transitions
* Two-to-four-pixel movement
* Soft border changes
* Slight image scaling on hover
* Smooth accordion opening
* Refined underline animation
* Calm button press states
* Minimal navigation transitions

Most transitions should occur between approximately 150 and 250 milliseconds.

Use smooth easing.

Respect reduced-motion preferences.

Avoid:

* Elements flying across the screen
* Large scroll-triggered reveals
* Parallax
* Scroll-jacking
* Constant animation
* Floating objects
* Pulsing buttons
* Animated backgrounds
* Particle systems
* Large zoom effects
* Spinning icons
* Automatic carousels
* Excessive page transitions

The interface should feel responsive, not animated.

## Hover States

Hover states should remain subtle.

Suitable hover responses include:

* Slight border darkening
* Small background tint
* Minor shadow increase
* Two-pixel upward movement
* Gentle image scale
* Link underline movement
* Icon shift of only a few pixels

Do not combine several hover effects on one component.

Avoid dramatic scaling or movement.

## Mobile Aesthetic

The mobile version must retain the same premium visual quality as desktop.

Do not simply stack every desktop component into a long column of identical cards.

Preserve:

* Strong typography
* Generous margins
* Clear hierarchy
* Intentional image crops
* Refined spacing
* Layered surfaces
* Visual rhythm
* Brand consistency

Use edge-to-edge imagery selectively.

Balance full-width visual moments with carefully padded text sections.

Buttons and form controls should remain comfortable to use without appearing oversized.

Navigation, sticky elements, and mobile action controls should feel integrated into the design rather than resembling advertisements.

Avoid:

* Tiny margins
* Crowded cards
* Oversized sticky bars
* Floating buttons covering content
* Excessive horizontal carousels
* Large blocks of centered text
* Repetitive card stacks
* Compressed typography
* Desktop layouts merely scaled down

## Responsive Behavior

The design should adapt gracefully rather than abruptly.

As screen width decreases:

* Reduce decorative complexity
* Preserve hierarchy
* Maintain readable line lengths
* Keep image focal points visible
* Rebalance whitespace
* Simplify multi-column layouts
* Preserve consistent control sizing
* Avoid awkward text wrapping
* Prevent crowded navigation

Tablet layouts should feel intentionally designed, not like an intermediate breakpoint.

## Visual Consistency

Maintain strict consistency across the entire website.

The same design language must govern:

* Typography
* Colors
* Spacing
* Radiuses
* Borders
* Shadows
* Iconography
* Buttons
* Inputs
* Images
* Cards
* Navigation
* Motion
* Section spacing

Do not introduce new visual styles from page to page.

Every page should feel like part of one cohesive branded system.

## Visual Restraint

Sophistication must come from:

* Typography
* Composition
* Photography
* Alignment
* Whitespace
* Proportion
* Hierarchy
* Material depth
* Consistency
* Fine details

Do not attempt to create sophistication through:

* More colors
* More gradients
* More animations
* More cards
* More icons
* More decorative shapes
* More shadows
* More effects
* More background patterns
* More oversized typography

Every visual element must have a clear purpose.

When an element does not improve clarity, hierarchy, usability, or brand perception, remove it.

## Final Visual Standard

The finished website should feel custom, mature, highly polished, and immediately credible.

It should resemble a professionally commissioned website for an established organization rather than a theme customized with different text and images.

The visual system should be distinctive enough to feel branded, but restrained enough to remain timeless.

The result should look modern for many years rather than following a temporary design trend.

Before considering the design complete, review every screen for:

* Inconsistent spacing
* Weak alignment
* Accidental text wrapping
* Overuse of cards
* Excessive rounded corners
* Competing colors
* Unnecessary shadows
* Generic stock imagery
* Low-contrast typography
* Inconsistent image treatment
* Repetitive section layouts
* Poor mobile composition
* Decorative clutter
* Oversized interface elements
* Weak hierarchy
* Template-like patterns

Refine the design until every page appears intentionally art-directed and visually cohesive.

