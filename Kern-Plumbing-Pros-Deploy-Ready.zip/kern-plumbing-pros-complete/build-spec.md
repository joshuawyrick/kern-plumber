# BUILD-SPEC.md — Kern Plumbing Pros (repo mode)
### This repository contains everything needed to build the complete site. Execute autonomously: work through the BUILD ORDER in section 12 phase by phase without waiting for approval between phases. Only stop if a required file is missing or an instruction is impossible.

You are building a production-quality local service business website. Follow every instruction exactly. Do not skip sections, substitute your own architecture, or invent any business facts.

## 1. PROJECT CONTEXT
Business: Kern Plumbing Pros, a plumbing company serving Kern County, CA, based in Bakersfield.
Phone (sitewide, all CTAs): (661) 555-0142 | Public email: contact@kernplumbingpros.com | Hours: 24/7 — emergency service available.
Lead email (form recipient, ONE config value): leads@kernplumbingpros.com
Goal: rank #1 in Google local organic results, be cited by AI search engines (ChatGPT, Perplexity, Gemini), and convert visitors into phone calls, text messages, and form submissions.

## 2. SOURCES — ALL IN THIS REPOSITORY
- **design-direction.md** — the aesthetic constitution. Governs every visual decision. Where it and section 5 overlap, design-direction.md wins on aesthetics; section 5's functional conversion elements must be KEPT and styled to comply.
- **content-pack-*.md** — all page copy. For every page: implement its TITLE, META, H1, body sections, FAQs, IMAGE-ALTS, and LINK-ANCHORS **VERBATIM**. Never rewrite, shorten, or "improve" pack copy. Never write your own marketing claims anywhere — hero copy, trust badges, card text all come from packs only. If a page's block is missing, build route + title + meta + H1 + breadcrumb only and list it in the final report. Never use lorem ipsum.
Pack inventory: content-pack-en-core.md · content-pack-en-services-batch1..4.md · content-pack-en-cities.md · content-pack-en-city-services-{delano,taft,arvin,tehachapi}.md · content-pack-es-core.md · content-pack-es-services-and-cities.md · content-pack-es-city-services-delano-arvin.md

## 3. TECHNICAL REQUIREMENTS (non-negotiable)
1. Build with **Astro** as a fully static site — every page complete, crawlable HTML readable without executing JavaScript. Never a client-rendered SPA. Keep all content-pack and spec .md files in the repo; exclude them from the built site output.
2. Semantic HTML: one <h1> per page, logical heading order, <header>, <nav>, <main>, <footer> landmarks.
3. Unique <title> (≤60 chars) and meta description (≤155 chars) per page, from the packs.
4. sitemap.xml (all indexable pages, EN + ES), robots.txt (allow all, reference sitemap), self-referencing canonicals. /thank-you/, /es/gracias/, and 404 carry noindex and are excluded from the sitemap.
5. Open Graph + Twitter card meta on every page: og:title, og:description, og:url, og:type, og:image (sitewide 1200×630 placeholder slot).
6. Performance: all images WebP with explicit width/height (zero layout shift), lazy-load below the fold, preload hero image, self-hosted fonts with font-display: swap, no render-blocking third-party scripts, full favicon set (16, 32, 180 apple-touch, 192/512 manifest).
7. Accessibility: pack alt text, visible <label> on every input, WCAG AA contrast, 44px tap targets, visible focus states, prefers-reduced-motion respected.
8. All phone numbers are tel: links (tel:+16615550142); all "Text" CTAs are sms: links (sms:+16615550142). Every displayed number renders from ONE shared component/constant.
9. Image placeholders: --surface-2 blocks at exact final dimensions, 12px radius, faint centered image icon, pack alt text. No stock photos, no AI imagery, no emoji.
10. Never fabricate reviews, ratings, counts, years, licenses, certifications, awards, or trust claims. Review sections are labeled placeholder slots. No star iconography anywhere until real reviews exist.

## 4. MEASUREMENT & TRACKING
1. GA4 snippet on every page, placeholder G-XXXXXXXXXX, comment <!-- REPLACE WITH REAL GA4 ID -->.
2. tel: links fire GA4 phone_click (page_path param); sms: links fire sms_click; /thank-you/ and /es/gracias/ arrival fires lead_form_submit. Mark each /* GA4 conversion */.
3. CallRail: <!-- CALLRAIL DNI SNIPPET HERE --> slot in every page head.

## 5. DESIGN SPEC LAYER (concrete values; design-direction.md governs taste)
1. Tokens (CSS variables, exclusive): --bg #FAFAF8 warm white (page); --surface #FFFFFF; --surface-2 #F4F5F7 (alt sections, placeholders, icon containers, footer); --text #1F2733 deep graphite; --text-2 #5B6470 muted slate; --border #E4E7EB (1px); --accent #1A56DB deep blue — the ONLY action color (buttons, links, focus, active nav, small details). No dark sections anywhere: bright hero, pale-gray footer, zero gradients, flat surfaces.
2. Typography: **Manrope** only (400/500/600/700/800), self-hosted, swap. H1 46px/34px, weight 800, -0.02em, lh 1.12, left-aligned, deliberate line breaks. H2 30/25 weight 700. Body 17px/1.7/max 68ch; --text-2 secondary. Eyebrow labels above section H2s: 13px, 600, +0.06em, uppercase, --accent, used sparingly.
3. Signature element (once per page): homepage hero = bright 55/45 split per design-direction.md — left: eyebrow, H1, subhead, primary "Call (661) 555-0142" + secondary "Request Service" (every button labeled), quiet trust-badge row (pack copy only, small accent check icons); right: large framed image placeholder with a compact white panel overlapping its lower-left corner — 1px border, subtle shadow, label "CALL OR TEXT — 24/7" (13px accent uppercase) + phone at 32px Manrope 700 tabular figures as a tel: link. Interior pages: the oversized phone treatment appears once, in the top CTA band.
4. Icons: Lucide line icons only — 1.5px stroke, 22px, --text or --accent, sparing, inside small --surface-2 rounded containers where grouping helps. Service mapping: droplets, flame, siren/zap, search, route, workflow, wrench, fuel. NO emoji anywhere.
5. Functional conversion elements (keep, styled quiet per the constitution): 36px --surface-2 utility top bar — "24/7 Emergency Plumbing — Call (661) 555-0142" with accent tel: link; single-row white sticky header (logo left, quiet nav, ES toggle chip, ONE dominant call button); --surface-2 footer, 4 columns, never dark; integrated compact mobile sticky bar (<768px): Call (primary) / Text (secondary) / Quote (secondary), 1px top border, safe-area-inset-bottom.
6. Motion: 150–250ms, soft easing, subtle only; no parallax, carousels, scroll-jacking, or animated backgrounds.

## 6. SITE ARCHITECTURE
English routes:
- / · /services/ (hub) · /services/{drain-cleaning, water-heater-repair, emergency-plumbing, leak-detection, sewer-line-repair, repiping, toilet-faucet-repair, gas-line-services}/
- /locations/ (hub) · /locations/{bakersfield-ca, delano-ca, arvin-ca, taft-ca, tehachapi-ca}/
- /locations/{city}/{service}/ for the FOUR SECONDARY cities only (delano-ca, arvin-ca, taft-ca, tehachapi-ca × 8 services = 32 routes). NEVER create /locations/bakersfield-ca/{service}/ — the main /services/ pages already target Bakersfield; duplicates cannibalize.
- /about/ · /contact/ · /reviews/ · /emergency/ (route + stub; full content pack later) · /thank-you/ (noindex) · custom 404 · /privacy-policy/ · /terms/
Spanish routes (per the ES packs' PAGE headings): /es/ core pages, /es/servicios/ hub + 8 service pages, /es/areas-de-servicio/ hub + 5 city pages, and the 16 Delano/Arvin service-in-city pages. Reciprocal hreflang (en, es, x-default → English) on every EN/ES pair; ES pages missing a twin-specific pack (Taft/Tehachapi service-in-city) simply don't exist in ES — their EN pages carry en + x-default only. Header ES toggle links each page to its exact twin (hidden where no twin exists).
URL rules: lowercase, hyphens, trailing slash, no dates, no query strings.

## 7. GLOBAL ELEMENTS (every page)
1. Header per 5.5. Nav: Services (dropdown of 8), Service Areas (dropdown of 5), About, Reviews, Contact. Spanish pages: mirrored nav labels (Servicios, Áreas de Servicio, Nosotros, Reseñas, Contacto) linking within /es/.
2. Footer 4 columns: (1) NAP — Kern Plumbing Pros, Serving Kern County, CA, tel (661) 555-0142, contact@kernplumbingpros.com; (2) service links; (3) city links; (4) hours + "Upfront pricing — you approve the price before work begins" + "Licensed & insured plumbers". NAP identical everywhere, character for character (Spanish footer: same NAP, localized labels).
3. Breadcrumbs (except homepages) with BreadcrumbList schema.
4. Sitewide LocalBusiness schema, subtype "Plumber": name Kern Plumbing Pros, telephone (661) 555-0142, email contact@kernplumbingpros.com, areaServed Bakersfield/Delano/Arvin/Taft/Tehachapi (Kern County, CA), openingHours 24/7, url https://kernplumbingpros.com. Identical everywhere. NEVER output AggregateRating or Review schema without real on-page reviews.
5. FAQPage schema on every page with a FAQ section, from pack Q&As.

## 8. LEAD FORM (homepage, contact, and every page whose pack includes a form section)
Name, Phone (validated), City (dropdown: the 5 cities + Other), "What do you need help with?" (textarea). Labels above fields, enterprise-clean. Hidden honeypot field ("website"); if filled, silently reject. Submit "Request Service" → /thank-you/ (fires lead_form_submit). Spanish forms: localized labels, submit "Solicitar Servicio" → /es/gracias/. Leads email to leads@kernplumbingpros.com via a form service; recipient in ONE config value; comment marks the endpoint slot.

## 9. INTERNAL LINKING
Per each pack's LINK-ANCHORS, plus: homepage links every service and city page; service pages link their secondary-city variants + 2–3 related services + locations hub; anchors descriptive, never "click here"; EN and ES networks stay within their language (plus the toggle).

## 10. WHAT NOT TO DO
No lorem ipsum. No fabricated facts or claims. No rewriting pack copy. No emoji. No gradients. No dark sections. No stock photos. No carousels, pop-ups, autoplay. No hidden text or keyword stuffing. No client-side-only content. No AggregateRating without real reviews. No unlabeled buttons.

## 11. QUALITY BAR PER PHASE
After each phase, run the build; fix errors before proceeding. Spot-check two pages per phase against their pack blocks for verbatim fidelity.

## 12. BUILD ORDER — execute all phases autonomously, in order
1. **Foundation**: Astro scaffold, tokens, typography, global components (utility bar, header, footer, sticky bar, breadcrumbs, schema, form component, GA4/CallRail wiring), full EN route tree with stubs, sitemap/robots/canonicals/OG.
2. **Core pages**: implement content-pack-en-core.md (/, /about/, /contact/, /reviews/, /thank-you/, 404) — including the signature hero.
3. **Service pages**: content-pack-en-services-batch1.md through batch4.md (8 pages) + /services/ hub (intro line + linked grid; no invented copy).
4. **City pages**: content-pack-en-cities.md (5 pages) + /locations/ hub (same rule).
5. **Service-in-city**: the four city slice packs (32 pages) — delano, taft, arvin, tehachapi.
6. **Spanish layer**: content-pack-es-core.md, content-pack-es-services-and-cities.md, content-pack-es-city-services-delano-arvin.md — all /es/ routes, localized nav/footer/forms, reciprocal hreflang across every pair, ES toggle live, sitemap extended.
7. **Final audit + report**: list every route built (count expected: ~90 pages EN+ES); confirm sitemap/robots/noindex handling; confirm GA4 events, CallRail slots, honeypot; grep the codebase for "lorem" (must be zero) and emoji (must be zero); confirm zero gradients and dark sections; confirm all buttons labeled; confirm Manrope-only and Lucide-only; list any missing pack blocks; list any design-direction.md rules you could not satisfy and why.
